/*
 * Copyright 2009 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query.qom;

/**
 * Evaluates to a set of node-tuples.
 *
 * @since JCR 2.0
 */
public interface Source {
}
