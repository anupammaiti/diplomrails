/*
 * Copyright 2009 Day Management AG, Switzerland. All rights reserved.
 */
package javax.jcr.query.qom;

/**
 * An operand to a binary operation specified by a {@link Comparison}.
 *
 * @since JCR 2.0
 */
public interface Operand {
}
